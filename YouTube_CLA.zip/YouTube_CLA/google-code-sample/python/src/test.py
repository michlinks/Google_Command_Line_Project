

video_id = []
video_name = []
PLAY = 0
playing  = 0

with open("videos.txt", "r") as filestream:
    with open("videos_formatted.txt", "w") as filestreamtwo:
        for line in filestream:
            currentline = [x.strip() for x in line.split('|')]  # separate into columns and remove whitespace
            total = str(currentline[0] + currentline[1] + currentline[2]) + "\n"
            video_name.append(currentline[0])
            video_id.append(currentline[1])
            filestreamtwo.write(total)
while True:
    video_request = input("PLAY ")
    if video_request in video_id and PLAY == 0:
        video_index = video_id.index(video_request)
        print("Playing video: ", video_name[video_index], "\n")
        PLAY = 1
        playing = video_name[video_index]
    elif video_request in video_id and PLAY == 1:
        playing = video_name[video_index]
        video_index = video_id.index(video_request)
        print("Stopping video: ", playing)
        print("Playing video: ", video_name[video_index], "\n")
    else:
        print("Cannot play video: Video does not exist \n")



