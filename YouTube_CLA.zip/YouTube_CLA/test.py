#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thur July 1 11:38:12 2021

@author: michaelalinks
"""

import typer

app = typer.Typer()  # create object


@app.command()  # decorator
def hello(name: str, iq: int, display_iq: bool = False):
    print(f"Hello {name}")
    if display_iq:
        print(f"Your IQ is {iq}")


if __name__ == "__main__":
    app()